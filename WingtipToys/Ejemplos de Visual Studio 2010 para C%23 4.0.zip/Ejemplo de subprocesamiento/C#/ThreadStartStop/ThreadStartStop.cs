﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

using System;
using System.Threading;

public class Worker
{
    // Este método se llama cuando se inicia el subproceso.
    public void DoWork()
    {
        while (!_shouldStop)
        {
            Console.WriteLine("worker thread: working...");
        }
        Console.WriteLine("worker thread: terminating gracefully.");
    }
    public void RequestStop()
    {
        _shouldStop = true;
    }
    // Se utiliza Volatile para indicar al compilador que varios subprocesos
    // obtendrán acceso a este miembro de datos.
    private volatile bool _shouldStop;
}

public class WorkerThreadExample
{
    static void Main()
    {
        // Crear el objeto de subproceso. Esto no inicia el subproceso.
        Worker workerObject = new Worker();
        Thread workerThread = new Thread(workerObject.DoWork);

        // Iniciar el subproceso de trabajo.
        workerThread.Start();
        Console.WriteLine("main thread: Starting worker thread...");

        // Realizar un bucle hasta que se active el subproceso de trabajo.
        while (!workerThread.IsAlive);

        // Dejar en suspensión el subproceso principal durante 1 milisegundo para
        // dejar actuar al subproceso de trabajo:
        Thread.Sleep(1);

        // Solicitar que el subproceso de trabajo se detenga:
        workerObject.RequestStop();

        // Utilizar el método Join para bloquear el subproceso actual
        // hasta que termine el subproceso del objeto.
        workerThread.Join();
        Console.WriteLine("main thread: Worker thread has terminated.");
    }
}