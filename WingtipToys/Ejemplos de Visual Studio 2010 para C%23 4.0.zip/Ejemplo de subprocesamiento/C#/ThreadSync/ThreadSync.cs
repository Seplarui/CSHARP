﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;

// Los eventos de sincronización de subprocesos están encapsulados en esta
// clase para permitir pasarlos fácilmente a las clases Consumer y
// Producer. 
public class SyncEvents
{
    public SyncEvents()
    {
        // Se utiliza AutoResetEvent para el evento "new item" porque
        // queremos que este evento se restablezca automáticamente cada vez que
        // el subproceso de consumidor responda a este evento.
        _newItemEvent = new AutoResetEvent(false);

        // Se utiliza ManualResetEvent para el evento "exit" porque
        // queremos que varios subprocesos respondan cuando se señale este
        // evento. Si utilizásemos AutoResetEvent en su lugar, el objeto de evento
        // se revertiría a un estado no señalado con un solo
        // subproceso respondido y el otro subproceso daría error
        // y terminaría.
        _exitThreadEvent = new ManualResetEvent(false);

        // Los dos eventos se colocan también en una matriz WaitHandle de manera
        // que el subproceso de consumidor se pueda bloquear en ambos eventos utilizando
        // el método WaitAny.
        _eventArray = new WaitHandle[2];
        _eventArray[0] = _newItemEvent;
        _eventArray[1] = _exitThreadEvent;
    }

    // Las propiedades públicas permiten el acceso seguro a los eventos.
    public EventWaitHandle ExitThreadEvent
    {
        get { return _exitThreadEvent; }
    }
    public EventWaitHandle NewItemEvent
    {
        get { return _newItemEvent; }
    }
    public WaitHandle[] EventArray
    {
        get { return _eventArray; }
    }

    private EventWaitHandle _newItemEvent;
    private EventWaitHandle _exitThreadEvent;
    private WaitHandle[] _eventArray;
}

// La clase Producer agrega elementos a la cola de forma asincrónica (utilizando
// un subproceso de trabajo) hasta que hay 20 elementos.
public class Producer 
{
    public Producer(Queue<int> q, SyncEvents e)
    {
        _queue = q;
        _syncEvents = e;
    }
    public void ThreadRun()
    {
        int count = 0;
        Random r = new Random();
        while (!_syncEvents.ExitThreadEvent.WaitOne(0, false))
        {
            lock (((ICollection)_queue).SyncRoot)
            {
                while (_queue.Count < 20)
                {
                    _queue.Enqueue(r.Next(0, 100));
                    _syncEvents.NewItemEvent.Set();
                    count++;
                }
            }
        }
        Console.WriteLine("Producer thread: produced {0} items", count);
    }
    private Queue<int> _queue;
    private SyncEvents _syncEvents;
}

// La clase Consumer utiliza su propio subproceso de trabajo para consumir elementos
// de la cola. La clase Producer notifica a la clase Consumer
// los nuevos elementos con el evento NewItemEvent.
public class Consumer
{
    public Consumer(Queue<int> q, SyncEvents e)
    {
        _queue = q;
        _syncEvents = e;
    }
    public void ThreadRun()
    {
        int count = 0;
        while (WaitHandle.WaitAny(_syncEvents.EventArray) != 1)
        {
            lock (((ICollection)_queue).SyncRoot)
            {
                int item = _queue.Dequeue();
            }
            count++;
        }
        Console.WriteLine("Consumer Thread: consumed {0} items", count);
    }
    private Queue<int> _queue;
    private SyncEvents _syncEvents;
}

public class ThreadSyncSample
{
    private static void ShowQueueContents(Queue<int> q)
    {
        // Enumerar una colección es intrínsecamente inseguro para subprocesos,
        // por lo que es imperativo que la colección se bloquee en la
        // enumeración para evitar que los subprocesos de consumidor y productor
        // modifiquen el contenido. (A este método lo llama únicamente
        // el subproceso principal.)
        lock (((ICollection)q).SyncRoot)
        {
            foreach (int i in q)
            {
                Console.Write("{0} ", i);
            }
        }
        Console.WriteLine();
    }

    static void Main()
    {
        // Configurar el struct que contiene información de eventos necesaria
        // para la sincronización de subprocesos. 
        SyncEvents syncEvents = new SyncEvents();

        // La colección genérica Queue se utiliza para almacenar elementos
        // para producir y consumir. En este caso, se usa 'int'.
        Queue<int> queue = new Queue<int>();

        // Crear objetos, uno para producir elementos y otro para
        // consumir. Los eventos de cola y sincronización de subprocesos
        // se pasan a ambos objetos.
        Console.WriteLine("Configuring worker threads...");
        Producer producer = new Producer(queue, syncEvents);
        Consumer consumer = new Consumer(queue, syncEvents);

        // Crear los objetos de subproceso para objetos Producer y Consumer.
        // Este paso no crea ni inicia los subprocesos
        // reales.
        Thread producerThread = new Thread(producer.ThreadRun);
        Thread consumerThread = new Thread(consumer.ThreadRun);

        // Crear e iniciar ambos subprocesos.     
        Console.WriteLine("Launching producer and consumer threads...");        
        producerThread.Start();
        consumerThread.Start();

        // Permitir que los subprocesos de productor y consumidor se ejecuten durante 10 segundos.
        // Utilizar el subproceso principal (que ejecuta este método)
        // para mostrar el contenido de la cola cada 2,5 segundos.
        for (int i = 0; i < 4; i++)
        {
            Thread.Sleep(2500);
            ShowQueueContents(queue);
        }

        // Señalar ambos subprocesos, de consumidor y de productor, para terminar.
        // Ambos subprocesos responderán porque ExitThreadEvent es un
        // evento de restablecimiento manual; por tanto, permanece 'set' a menos que se restablezca explícitamente.
        Console.WriteLine("Signaling threads to terminate...");
        syncEvents.ExitThreadEvent.Set();

        // Utilizar Join para bloquear el subproceso principal, primero hasta que termine el
        // subproceso de productor y después hasta que termine el subproceso de consumidor.
        Console.WriteLine("main thread waiting for threads to finish...");
        producerThread.Join();
        consumerThread.Join();
    }
}
