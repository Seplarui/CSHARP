﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// indexer.cs
// argumentos: indexer.txt
using System;
using System.IO;

// Clase que proporciona acceso a un archivo grande
// como si fuese una matriz de bytes.
public class FileByteArray
{
    Stream stream;      // Contiene la secuencia subyacente
                        // utilizada para obtener acceso al archivo.
// Crear un nuevo FileByteArray que encapsule un archivo concreto.
    public FileByteArray(string fileName)
    {
        stream = new FileStream(fileName, FileMode.Open);
    }

    // Cerrar la secuencia. Ésta debe ser la  última cosa que haga
    // cuando termine.
    public void Close()
    {
        stream.Close();
        stream = null;
    }

    // Indizador para proporcionar acceso de lectura y escritura al archivo.
    public byte this[long index]   // long es un entero de 64 bits
    {
        // Leer un byte en el desplazamiento que indica index y devolverlo.
        get 
        {
            byte[] buffer = new byte[1];
            stream.Seek(index, SeekOrigin.Begin);
            stream.Read(buffer, 0, 1);
            return buffer[0];
        }
        // Escribir un byte en el desplazamiento que indica index y devolverlo.
        set 
        {
            byte[] buffer = new byte[1] {value};
            stream.Seek(index, SeekOrigin.Begin);
            stream.Write(buffer, 0, 1);
        }
    }

    // Obtener la longitud total del archivo.
    public long Length 
    {
        get 
        {
            return stream.Seek(0, SeekOrigin.End);
        }
    }
}

// Mostrar la clase FileByteArray.
// Invierte los bytes de un archivo.
public class Reverse 
{
    public static void Main(String[] args) 
    {
		// Comprobar si hay argumentos.
		if (args.Length != 1)
		{
			Console.WriteLine("Usage : Indexer <filename>");
			return;
		}

		// Comprobar si existe el archivo
		if (!System.IO.File.Exists(args[0]))
		{
			Console.WriteLine("File " + args[0] + " not found.");
			return;
		}

		FileByteArray file = new FileByteArray(args[0]);
		long len = file.Length;

		// Intercambiar bytes en el archivo para invertirlo.
		for (long i = 0; i < len / 2; ++i) 
		{
			byte t;

			// Tenga en cuenta que al indizar la variable "file", se invoca al
			// indizador en la clase FileByteStream, que lee
			// y escribe los bytes en el archivo.
			t = file[i];
			file[i] = file[len - i - 1];
			file[len - i - 1] = t;
		}

		file.Close();
    } 
}

