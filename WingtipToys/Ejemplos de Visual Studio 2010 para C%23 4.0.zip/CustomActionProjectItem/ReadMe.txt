﻿' Copyright © Microsoft Corporation.  Reservados todos los derechos.
' Este código se publica según los términos 
' de licencia pública de Microsoft (MS-PL, 
' http://go.microsoft.com/?linkid=9791213).


Éste es un ejemplo de una extensión de Visual Studio 2010 para usarla con las 
nuevas plantillas de proyecto de SharePoint.  Aprovecha las ventajas de las API 
de extensibilidad que forman parte de las nuevas herramientas de desarrollo de 
SharePoint en Visual Studio 2010. La extensión es para una acción personalizada 
de SharePoint.  Para poder usar este ejemplo correctamente, debe tener 
instalado el SDK de Visual Studio 2010.  Se puede descargar aquí: 
http://go.microsoft.com/fwlink/?LinkId=164562.

La solución contiene dos proyectos:
- Un proyecto de biblioteca de clases que implementa la extensión.
- Un proyecto VSIX que empaqueta la extensión en un archivo VSIX. Este archivo 
  se usa para instalar la extensión.

Para ejecutar el ejemplo, abra la versión para Visual Basic o C# de la solución 
CustomActionProjectItem en Visual Studio 2010 y presione F5. Se producen las 
siguientes acciones:
- Se compila la extensión a partir del proyecto ProjectItemDefinition.
- Se crea el paquete VSIX a partir del proyecto CustomActionProjectItem.
- Se inicia una instancia experimental de Visual Studio en la que se instala el 
  paquete VSIX.

En la instancia experimental de Visual Studio puede probar la acción 
personalizada; para ello, lleve a cabo lo siguiente:
- Cree un nuevo proyecto vacío de SharePoint. Esta plantilla de proyecto está 
  disponible cuando se selecciona el nodo 2010 en el nodo SharePoint del cuadro 
  de diálogo Nuevo proyecto. Use el mismo lenguaje de programación (Visual 
  Basic o C#) que la versión del proyecto CustomActionProjectItem que abrió.
- En el Asistente para la personalización de SharePoint, escriba la dirección 
  URL de un sitio de SharePoint en su equipo local y haga clic en "Finalizar".
- Una vez creado el proyecto, haga clic con el botón secundario del mouse en el 
  nodo del proyecto, en el Explorador de soluciones, y seleccione "Agregar" | 
  "Nuevo elemento...".
- En el cuadro de diálogo Agregar nuevo elemento, haga clic en el nodo 
  "SharePoint", seleccione el elemento "Acción personalizada" y, a 
  continuación, haga clic en "Agregar".

La acción personalizada se agrega al proyecto. Puede probar las tareas 
siguientes:
- En el Explorador de soluciones, haga clic con el botón secundario en el nodo 
  CustomAction y haga clic en el elemento de menú “Ver diseñador de acciones 
  personalizadas”. Este elemento de menú contextual es agregado por la 
  extensión.
- En el Explorador de soluciones, seleccione el nodo CustomAction y, a 
  continuación, abra la ventana Propiedades. Compruebe que aparece la propiedad 
  personalizada “Custom Action Property” en la ventana de propiedades. Esta 
  propiedad es agregada por la extensión. 
- Modifique el archivo Elements.xml en el elemento de proyecto CustomAction y 
  presione F5 para implementarlo en el sitio local especificado al crear el 
  proyecto.



