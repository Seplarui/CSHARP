// Copyright � Microsoft Corporation. Reservados todos los derechos.
// Este c�digo se ha publicado de acuerdo con los t�rminos de la 
// licencia p�blica de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).

using System;
using System.Diagnostics;
using System.ComponentModel;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.SharePoint;

namespace Contoso.SharePointProjectItems.CustomAction
{
    // Permite que Visual Studio detecte y cargue esta extensi�n.
    [Export(typeof(ISharePointProjectItemTypeProvider))]

    // Especifica el id. de este nuevo tipo de elemento de proyecto. Esta cadena debe coincidir con el valor del 
    // atributo Type del elemento ProjectItem en el archivo .spdata del elemento de proyecto.
    [SharePointProjectItemType("Contoso.CustomAction")]

    // Especifica el icono que se muestra con el elemento de proyecto en el Explorador de soluciones.
    [SharePointProjectItemIcon("ProjectItemDefinition.CustomAction_SolutionExplorer.ico")]

    // Define un nuevo tipo de elemento de proyecto que se puede usar para crear una acci�n personalizada en un sitio de SharePoint.
    internal partial class CustomActionProvider : ISharePointProjectItemTypeProvider
    {
        private ISharePointProjectService projectService;

        // Implementa IProjectItemTypeProvider.InitializeType. Configura el comportamiento del tipo de elemento de proyecto.
        public void InitializeType(ISharePointProjectItemTypeDefinition projectItemTypeDefinition)
        {
            projectItemTypeDefinition.Name = "CustomAction";
            projectItemTypeDefinition.SupportedDeploymentScopes =
                SupportedDeploymentScopes.Site | SupportedDeploymentScopes.Web;
            projectItemTypeDefinition.SupportedTrustLevels = SupportedTrustLevels.All;

            // Obtener el servicio para que pueda utilizarlo otro c�digo de esta clase.
            projectService = projectItemTypeDefinition.ProjectService;

            // Controlar algunos eventos de elementos de proyecto.
            projectItemTypeDefinition.ProjectItemInitialized += ProjectItemInitialized;
            projectItemTypeDefinition.ProjectItemNameChanged += ProjectItemNameChanged;
            projectItemTypeDefinition.ProjectItemDisposing += ProjectItemDisposing;

            // Controlar eventos para crear una propiedad personalizada y un elemento de men� contextual para este elemento de proyecto.
            projectItemTypeDefinition.ProjectItemPropertiesRequested +=
                ProjectItemPropertiesRequested;
            projectItemTypeDefinition.ProjectItemMenuItemsRequested +=
                ProjectItemMenuItemsRequested;
        }

        private void ProjectItemInitialized(object sender, SharePointProjectItemEventArgs e)
        {
            // Controlar un evento del proyecto.
            e.ProjectItem.Project.PropertyChanged += ProjectPropertyChanged;
        }

        private void ProjectItemNameChanged(object sender, NameChangedEventArgs e)
        {
            ISharePointProjectItem projectItem = (ISharePointProjectItem)sender;
            string message = String.Format("The name of the {0} item changed to: {1}",
                e.OldName, projectItem.Name);
            projectService.Logger.WriteLine(message, LogCategory.Message);
        }

        private void ProjectPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            ISharePointProject project = (ISharePointProject)sender;
            string message = String.Format("The following property of the {0} project was changed: {1}",
                    project.Name, e.PropertyName);
            projectService.Logger.WriteLine(message, LogCategory.Message);
        }

        private void ProjectItemDisposing(object sender, SharePointProjectItemEventArgs e)
        {
            e.ProjectItem.Project.PropertyChanged -= ProjectPropertyChanged;
        }
    }
}