﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).

using Microsoft.VisualStudio.SharePoint;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Contoso.SharePointProjectItems.CustomAction
{
    internal partial class CustomActionProvider
    {
        private void ProjectItemPropertiesRequested(object sender,
            SharePointProjectItemPropertiesRequestedEventArgs e)
        {
            CustomActionProperties properties;

            // si el objeto de propiedades ya existe, obtenerlo de las anotaciones del elemento de proyecto.
            if (!e.ProjectItem.Annotations.TryGetValue(out properties))
            {
                // En caso contrario, crear un nuevo objeto de propiedades y agregarlo a las anotaciones.
                properties = new CustomActionProperties(e.ProjectItem);
                e.ProjectItem.Annotations.Add(properties);
            }

            e.PropertySources.Add(properties);
        }
    }

    internal class CustomActionProperties
    {
        private ISharePointProjectItem projectItem;
        private const string testPropertyId = "Contoso.CustomActionTestProperty";
        private const string propertyDefaultValue = "This is a test value.";

        internal CustomActionProperties(ISharePointProjectItem projectItem)
        {
            this.projectItem = projectItem;
        }

        // Obtiene o establece una propiedad de cadena simple. El valor de propiedad se almacena en la propiedad ExtensionData
        // del elemento de proyecto. Los datos de la propiedad ExtensionData persisten cuando se cierra el proyecto.
        [DisplayName("Custom Action Property")]
        [DescriptionAttribute("This is a test property for the Contoso Custom Action project item.")]
        [DefaultValue(propertyDefaultValue)]
        public string TestProperty
        {
            get
            {
                string propertyValue;

                // Obtener el valor de propiedad actual si ya existe; en caso contrario, devolver un valor predeterminado.
                if (!projectItem.ExtensionData.TryGetValue(testPropertyId, out propertyValue))
                {
                    propertyValue = propertyDefaultValue;
                }
                return propertyValue;
            }
            set
            {
                if (value != propertyDefaultValue)
                {
                    projectItem.ExtensionData[testPropertyId] = value;
                }
                else
                {
                    // No guardar el valor predeterminado.
                    projectItem.ExtensionData.Remove(testPropertyId);
                }
            }
        }
    }
}