﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

using System;
using System.Collections.Generic;
using System.Text;

namespace PartialClassesExample
{
    // La palabra clave partial permite definir otros métodos, campos y
    // propiedades de esta clase en otros archivos .cs.
    // Este archivo contiene los métodos públicos definidos por CharValues.
    partial class CharValues
    {
        public static int CountAlphabeticChars(string str)
        {
            int count = 0;
            foreach (char ch in str)
            {
                // IsAlphabetic se define en CharTypesPrivate.cs
                if (IsAlphabetic(ch))
                    count++;
            }
            return count;
        }
        public static int CountNumericChars(string str)
        {
            int count = 0;
            foreach (char ch in str)
            {
                // IsNumeric se define en CharTypesPrivate.cs
                if (IsNumeric(ch))
                    count++;
            }
            return count;
        }

    }
}

