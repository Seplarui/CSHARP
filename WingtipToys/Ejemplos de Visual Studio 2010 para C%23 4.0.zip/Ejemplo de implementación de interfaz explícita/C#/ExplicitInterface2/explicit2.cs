﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// explicit2.cs
// Declarar la interfaz de unidades inglesas:
interface IEnglishDimensions 
{
   float Length();
   float Width();
}
// Declarar la interfaz de unidades métricas:
interface IMetricDimensions 
{
   float Length();
   float Width();
}
// Declarar la clase "Box" que implementa las dos interfaces:
// IEnglishDimensions e IMetricDimensions:
class Box : IEnglishDimensions, IMetricDimensions 
{
   float lengthInches;
   float widthInches;
   public Box(float length, float width) 
   {
      lengthInches = length;
      widthInches = width;
   }
// Implementar de forma explícita los miembros de IEnglishDimensions:
   float IEnglishDimensions.Length() 
   {
      return lengthInches;
   }
   float IEnglishDimensions.Width() 
   {
      return widthInches;      
   }
// Implementar de forma explícita los miembros de IMetricDimensions:
   float IMetricDimensions.Length() 
   {
      return lengthInches * 2.54f;
   }
   float IMetricDimensions.Width() 
   {
      return widthInches * 2.54f;
   }
   public static void Main() 
   {
      // Declarar una instancia de clase "myBox":
      Box myBox = new Box(30.0f, 20.0f);
      // Declarar una instancia de la interfaz de unidades inglesas:
      IEnglishDimensions eDimensions = (IEnglishDimensions) myBox;
      // Declarar una instancia de la interfaz de unidades métricas:
      IMetricDimensions mDimensions = (IMetricDimensions) myBox;
      // Imprimir dimensiones en unidades inglesas:
      System.Console.WriteLine("Length(in): {0}", eDimensions.Length());
      System.Console.WriteLine("Width (in): {0}", eDimensions.Width());
      // Imprimir dimensiones en unidades métricas:
      System.Console.WriteLine("Length(cm): {0}", mDimensions.Length());
      System.Console.WriteLine("Width (cm): {0}", mDimensions.Width());
   }
}

