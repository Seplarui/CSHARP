﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// explicit1.cs
interface IDimensions 
{
   float Length();
   float Width();
}

class Box : IDimensions 
{
   float lengthInches;
   float widthInches;

   public Box(float length, float width) 
   {
      lengthInches = length;
      widthInches = width;
   }
   // Implementación explícita de miembro de la interfaz: 
   float IDimensions.Length() 
   {
      return lengthInches;
   }
   // Implementación explícita de miembro de la interfaz:
   float IDimensions.Width() 
   {
      return widthInches;      
   }

   public static void Main() 
   {
      // Declarar una instancia de clase "myBox":
      Box myBox = new Box(30.0f, 20.0f);
      // Declarar una instancia de interfaz "myDimensions":
      IDimensions myDimensions = (IDimensions) myBox;
      // Imprimir las dimensiones del cuadro:
      /* Las siguientes líneas comentadas producirían errores de
         compilación porque intentan obtener acceso a un miembro de
         interfaz implementado de forma explícita desde una instancia de clase:                   */
      //System.Console.WriteLine("Length: {0}", myBox.Length());
      //System.Console.WriteLine("Width: {0}", myBox.Width());
      /* Imprimir las dimensiones del cuadro llamando a los métodos
         desde una instancia de la interfaz:                         */
      System.Console.WriteLine("Length: {0}", myDimensions.Length());
      System.Console.WriteLine("Width: {0}", myDimensions.Width());
   }
}

