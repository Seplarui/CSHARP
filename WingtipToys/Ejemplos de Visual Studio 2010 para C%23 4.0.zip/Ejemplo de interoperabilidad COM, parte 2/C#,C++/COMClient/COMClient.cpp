﻿//(C) Microsoft Corporation. Reservados todos los derechos.

// cominteropPart2\COMClient.cpp
// Generar esta parte del ejemplo con la línea de comandos:
//  cl COMClient.cpp

#include <windows.h>
#include <stdio.h>

#pragma warning (disable: 4278)

// Para utilizar servidores de código administrado como el servidor de C#, 
// debemos importar Common Language Runtime:
#import <mscorlib.tlb> raw_interfaces_only

// Por simplicidad, omitimos el espacio de nombres del servidor y usamos GUID con nombre:
#if defined (USINGPROJECTSYSTEM)
#import "..\RegisterCSharpServerAndExportTLB\CSharpServer.tlb" no_namespace named_guids
#else  // Compilación desde la línea de comandos, todos los archivos en el mismo directorio
#import "CSharpServer.tlb" no_namespace named_guids
#endif
int main(int argc, char* argv[])
{
    IManagedInterface *cpi = NULL;
    int retval = 1;

    // Inicializar COM y crear una instancia de la clase InterfaceImplementation:
    CoInitialize(NULL);
    HRESULT hr = CoCreateInstance(CLSID_InterfaceImplementation,
                                  NULL,
                                  CLSCTX_INPROC_SERVER,
                                  IID_IManagedInterface,
                                  reinterpret_cast<void**>(&cpi));

    if (FAILED(hr))
    {
        printf("Couldn't create the instance!... 0x%x\n", hr);
    }
    else
    {
        if (argc > 1)
        {
            printf("Calling function.\n");
            // La variable cpi ahora contiene un puntero de interfaz          // a la interfaz administrada.
            // Si utiliza un sistema operativo que usa caracteres ASCII en el          // símbolo del sistema, tenga en cuenta que se calculan automáticamente las referencias de los caracteres ASCII
            // como Unicode para el código de C#.

            if (cpi->PrintHi(argv[1]) == 33)
                retval = 0;

            printf("Returned from function.\n");
        }
        else
            printf ("Usage:  COMClient <name>\n");
        cpi->Release();
        cpi = NULL;
    }

    // Sea un buen ciudadano y limpie COM:
    CoUninitialize();
    return retval;
}

