﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// conversion.cs
using System;

struct RomanNumeral
{
    public RomanNumeral(int value) 
    { 
       this.value = value; 
    }
    // Declarar una conversión de int a RomanNumeral. Observe
    // el uso de la palabra clave operator. Éste es un operador de conversión
    // denominado RomanNumeral:
    static public implicit operator RomanNumeral(int value) 
    {
       // Observe que, debido a que RomanNumeral está declarado como un struct, 
       // si se llama a new en el struct, sólo llama al constructor
       // en lugar de asignar un objeto en el montón:
       return new RomanNumeral(value);
    }
    // Declarar una conversión explícita de RomanNumeral a int:
    static public explicit operator int(RomanNumeral roman)
    {
       return roman.value;
    }
    // Declarar una conversión implícita de RomanNumeral a 
    // String:
    static public implicit operator string(RomanNumeral roman)
    {
       return("Conversion not yet implemented");
    }
    private int value;
}

class Test
{
    static public void Main()
    {
        RomanNumeral numeral;

        numeral = 10;

// Llamar a la conversión explícita de numeral a int. Puesto que es
// una conversión explícita, se debe utilizar una conversión:
        Console.WriteLine((int)numeral);

// Llamar a la conversión implícita a String. Puesto que no hay
// conversión, la conversión implícita a String es la única
// conversión que se considera:
        Console.WriteLine(numeral);
 
// Llamar a la conversión explícita de numeral a int y 
// después a la conversión explícita de int a short:
        short s = (short)numeral;

        Console.WriteLine(s);
    }
}

