﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// compose.cs
using System;

delegate void MyDelegate(string s);

class MyClass
{
    public static void Hello(string s)
    {
        Console.WriteLine("  Hello, {0}!", s);
    }

    public static void Goodbye(string s)
    {
        Console.WriteLine("  Goodbye, {0}!", s);
    }

    public static void Main()
    {
        MyDelegate a, b, c, d;

        // Crear el objeto delegado a que hace referencia
        // al método Hello:
        a = new MyDelegate(Hello);
        // Crear el objeto delegado b que hace referencia
        // al método Goodbye:
        b = new MyDelegate(Goodbye);
        // Los dos delegados, a y b, se combinan para formar c, 
        // que llama a ambos métodos por orden:
        c = a + b;
        // Quitar a del delegado compuesto, dejando d, 
        // que llama sólo al método Goodbye:
        d = c - a;

        Console.WriteLine("Invoking delegate a:");
        a("A");
        Console.WriteLine("Invoking delegate b:");
        b("B");
        Console.WriteLine("Invoking delegate c:");
        c("C");
        Console.WriteLine("Invoking delegate d:");
        d("D");
    }
}

