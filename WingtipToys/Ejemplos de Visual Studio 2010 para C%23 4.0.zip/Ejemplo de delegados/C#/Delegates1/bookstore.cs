﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// bookstore.cs
using System;

// Conjunto de clases para controlar una librería:
namespace Bookstore 
{
   using System.Collections;

   // Describe un libro en la lista de libros:
   public struct Book
   {
      public string Title;        // Título del libro.
      public string Author;       // Autor del libro.
      public decimal Price;       // Precio del libro.
      public bool Paperback;      // ¿Es de bolsillo?

      public Book(string title, string author, decimal price, bool paperBack)
      {
         Title = title;
         Author = author;
         Price = price;
         Paperback = paperBack;
      }
   }

   // Declarar un tipo de delegado para procesar un libro:
   public delegate void ProcessBookDelegate(Book book);

   // Mantiene una base de datos de libros.
   public class BookDB
   {
      // Lista de todos los libros de la base de datos:
      ArrayList list = new ArrayList();   

      // Agregar un libro a la base de datos:
      public void AddBook(string title, string author, decimal price, bool paperBack)
      {
         list.Add(new Book(title, author, price, paperBack));
      }

      // Llamar a un delegado pasado en cada libro de bolsillo para procesarlo: 
      public void ProcessPaperbackBooks(ProcessBookDelegate processBook)
      {
         foreach (Book b in list) 
         {
            if (b.Paperback)
            // Llamada al delegado:
               processBook(b);
         }
      }
   }
}

// Uso de las clases Bookstore:
namespace BookTestClient
{
   using Bookstore;

   // Clase para hallar el total y la media de precios de los libros:
   class PriceTotaller
   {
      int countBooks = 0;
      decimal priceBooks = 0.0m;

      internal void AddBookToTotal(Book book)
      {
         countBooks += 1;
         priceBooks += book.Price;
      }

      internal decimal AveragePrice()
      {
         return priceBooks / countBooks;
      }
   }

   // Clase para probar la base de datos de libros:
   class Test
   {
      // Imprimir el título del libro.
      static void PrintTitle(Book b)
      {
         Console.WriteLine("   {0}", b.Title);
      }

      // La ejecución comienza aquí.
      static void Main()
      {
         BookDB bookDB = new BookDB();

         // Inicializar la base de datos con algunos libros:
         AddBooks(bookDB);      

         // Imprimir todos los títulos de bolsillo:
         Console.WriteLine("Paperback Book Titles:");
         // Crear un nuevo objeto delegado asociado con el método estático
         // Test.PrintTitle:
         bookDB.ProcessPaperbackBooks(new ProcessBookDelegate(PrintTitle));

         // Obtener el precio medio de un libro de bolsillo utilizando
         // un objeto PriceTotaller:
         PriceTotaller totaller = new PriceTotaller();
         // Crear un nuevo objeto delegado asociado con el método no estático 
         // AddBookToTotal en el objeto totaller:
         bookDB.ProcessPaperbackBooks(new ProcessBookDelegate(totaller.AddBookToTotal));
         Console.WriteLine("Average Paperback Book Price: ${0:#.##}",
            totaller.AveragePrice());
      }

      // Inicializar la base de datos de libros con algunos libros de prueba:
      static void AddBooks(BookDB bookDB)
      {
         bookDB.AddBook("The C Programming Language", 
            "Brian W. Kernighan and Dennis M. Ritchie", 19.95m, true);
         bookDB.AddBook("The Unicode Standard 2.0", 
            "The Unicode Consortium", 39.95m, true);
         bookDB.AddBook("The MS-DOS Encyclopedia", 
            "Ray Duncan", 129.95m, false);
         bookDB.AddBook("Dogbert's Clues for the Clueless", 
            "Scott Adams", 12.00m, true);
      }
   }
}

