﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// interop2.cs
// Compilar con "csc interop2.cs"
using System;
using System.Runtime.InteropServices;

namespace QuartzTypeLib 
{
	// Declarar IMediaControl como una interfaz COM que
	// se deriva de la interfaz IDispatch:
	[Guid("56A868B1-0AD4-11CE-B03A-0020AF0BA770"), 
	InterfaceType(ComInterfaceType.InterfaceIsDual)] 
	interface IMediaControl   // No se puede mostrar una lista de interfaces base aquí
	{ 
		// Tenga en cuenta que los miembros de la interfaz IUnknown NO se enumeran aquí:

		void Run();

		void Pause();

		void Stop();

		void GetState( [In] int msTimeout, [Out] out int pfs);

		void RenderFile(
			[In, MarshalAs(UnmanagedType.BStr)] string strFilename);

		void AddSourceFilter( 
			[In, MarshalAs(UnmanagedType.BStr)] string strFilename, 
			[Out, MarshalAs(UnmanagedType.Interface)]
			out object ppUnk);

		[return: MarshalAs(UnmanagedType.Interface)] 
		object FilterCollection();

		[return: MarshalAs(UnmanagedType.Interface)] 
		object RegFilterCollection();
            
		void StopWhenReady(); 
	}
	// Declarar FilgraphManager como una coclase COM:
	[ComImport, Guid("E436EBB3-524F-11CE-9F53-0020AF0BA770")] 
	class FilgraphManager   // No se puede tener una lista de clases base o
		// interfaces aquí.
	{ 
		// No se pueden tener miembros aquí
		// TENGA EN CUENTA que el compilador de C# agregará un constructor predeterminado
		// por usted (sin parámetros).
	}
}

class MainClass 
{ 
	/********************************************************** 
	Resumen: este método recopila el nombre de archivo de un AVI para mostrarlo
	y después crea una instancia del objeto COM Quartz. 
	Para mostrar el AVI, el programa llama a RenderFile y Run
	en IMediaControl. Quartz utiliza sus propios subproceso y ventana para 
	mostrar el AVI. El subproceso principal se bloquea en un ReadLine hasta
	que el usuario presiona Entrar.
		Parámetros de entrada: ubicación del archivo avi que va a mostrar
		Devuelve: void
	*************************************************************/ 

	public static void Main(string[] args) 
	{ 
		// Comprobar si el usuario pasó un nombre de archivo:
		if (args.Length != 1) 
		{ 
			DisplayUsage();
			return;
		} 

		if (args[0] == "/?") 
		{ 
			DisplayUsage(); 
			return;
		}

		String filename = args[0]; 

		// Comprobar si el archivo existe
		if (!System.IO.File.Exists(filename))
		{
			Console.WriteLine("File " + filename + " not found.");
			DisplayUsage();
			return;
		}

		// Crear una instancia de Quartz 
		// (Calls CoCreateInstance(E436EBB3-524F-11CE-9F53-0020AF0BA770, 
		//  NULL, CLSCTX_ALL, IID_IUnknown, 
		//  &graphManager).):
		try
		{
			QuartzTypeLib.FilgraphManager graphManager =
				new QuartzTypeLib.FilgraphManager();

			// QueryInterface para la interfaz IMediaControl:
			QuartzTypeLib.IMediaControl mc = 
				(QuartzTypeLib.IMediaControl)graphManager;

			// Llamar a algunos métodos en una interfaz COM.
			// Pasar el archivo al método RenderFile en el objeto COM.
			mc.RenderFile(filename);
        
			// Mostrar el archivo. 
			mc.Run();
		}
		catch(Exception ex)
		{
			Console.WriteLine("Unexpected COM exception: " + ex.Message);
		}
		// Esperar que termine. 
		Console.WriteLine("Press Enter to continue."); 
		Console.ReadLine();
	}

	private static void DisplayUsage() 
	{ 
		// El usuario no proporcionó parámetros suficientes. 
		// Mostrar uso. 
		Console.WriteLine("VideoPlayer: Plays AVI files."); 
		Console.WriteLine("Usage: VIDEOPLAYER.EXE filename"); 
		Console.WriteLine("where filename is the full path and");
		Console.WriteLine("file name of the AVI to display."); 
	} 
}

