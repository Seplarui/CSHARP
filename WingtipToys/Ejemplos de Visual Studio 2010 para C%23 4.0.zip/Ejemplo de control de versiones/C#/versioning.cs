﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// versioning.cs
// Se esperaba CS0114
public class MyBase 
{
   public virtual string Meth1() 
   {
      return "MyBase-Meth1";
   }
   public virtual string Meth2() 
   {
      return "MyBase-Meth2";
   }
   public virtual string Meth3() 
   {
      return "MyBase-Meth3";
   }
}

class MyDerived : MyBase 
{
   // Invalida el método virtual Meth1 utilizando la palabra clave override:
   public override string Meth1() 
   {
      return "MyDerived-Meth1";
   }
   // Oculta de forma explícita el método virtual Meth2 utilizando la
   // palabra clave new:
   public new string Meth2() 
   {
      return "MyDerived-Meth2";
   }
   // Puesto que no se especifican palabras clave en la siguiente declaración,
   // se emite una advertencia para alertar al programador de que
   // el método oculta el miembro heredado MyBase.Meth3():
   public string Meth3() 
   {
      return "MyDerived-Meth3";
   }

   public static void Main() 
   {
      MyDerived mD = new MyDerived();
      MyBase mB = (MyBase) mD;

      System.Console.WriteLine(mB.Meth1());
      System.Console.WriteLine(mB.Meth2());
      System.Console.WriteLine(mB.Meth3());
   }
}

