﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// FunctionClient.cs
// compilar con: /reference:DigitCounter.dll;Factorial.dll
// argumentos: 3 5 10
using System; 
// La siguiente directiva pone disponibles los tipos definidos en el
// espacio de nombres Functions en esta unidad de compilación:
using Functions;
class FunctionClient 
{ 
    public static void Main(string[] args) 
    { 
        Console.WriteLine("Function Client"); 

        if ( args.Length == 0 ) 
        {
            Console.WriteLine("Usage: FunctionTest ... "); 
            return; 
        } 

        for ( int i = 0; i < args.Length; i++ ) 
        { 
            int num = Int32.Parse(args[i]); 
            Console.WriteLine(
               "The Digit Count for String [{0}] is [{1}]", 
               args[i], 
               // Invocar el método estático NumberOfDigits en la
               // clase DigitCount:
               DigitCount.NumberOfDigits(args[i])); 
            Console.WriteLine(
               "The Factorial for [{0}] is [{1}]", 
                num,
               // Invocar el método estático Calc en la clase Factorial:
                Factorial.Calc(num) ); 
        } 
    } 
}

