﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// Factorial.cs
// compilar con: /target:library
using System; 

// Declara un espacio de nombres. Debe empaquetar las bibliotecas de acuerdo con
// su espacio de nombres para que el motor de tiempo de ejecución de .NET pueda cargar correctamente las clases.
namespace Functions 
{ 
    public class Factorial 
    { 
// El método estático "Calc" calcula el valor factorial del
// entero especificado que se ha pasado:
        public static int Calc(int i) 
        { 
            return((i <= 1) ? 1 : (i * Calc(i-1))); 
        } 
    }
}

