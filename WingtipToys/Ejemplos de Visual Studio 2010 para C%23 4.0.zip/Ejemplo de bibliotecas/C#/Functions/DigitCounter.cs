﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// DigitCounter.cs
// compilar con: /target:library
using System; 

// Declarar el mismo espacio de nombres que en Factorial.cs. Éste simplemente
// permite agregar tipos al mismo espacio de nombres.
namespace Functions 
{
    public class DigitCount 
    {
        // El método estático NumberOfDigits calcula el número de
        // caracteres de dígito de la cadena pasada:
        public static int NumberOfDigits(string theString) 
        {
            int count = 0; 
            for ( int i = 0; i < theString.Length; i++ ) 
            {
                if ( Char.IsDigit(theString[i]) ) 
                {
                    count++; 
                }
            }
            return count;
        }
    }
}

