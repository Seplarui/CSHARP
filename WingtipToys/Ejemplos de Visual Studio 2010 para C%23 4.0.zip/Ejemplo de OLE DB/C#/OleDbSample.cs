﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// OleDbSample.cs
// Para generar este ejemplo desde la línea de comandos, utilice el comando:
// csc oledbsample.cs

using System;
using System.Data;
using System.Data.OleDb;
using System.Xml.Serialization;

public class MainClass 
{
	public static void Main ()
	{
		// Establecer la conexión con Access y seleccionar cadenas.
		// La ruta de acceso a BugTypes.MDB se debe cambiar si genera el ejemplo
		// desde la línea de comandos:
#if USINGPROJECTSYSTEM
		string strAccessConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=..\\..\\BugTypes.MDB";
#else
		string strAccessConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=BugTypes.MDB";
#endif
		string strAccessSelect = "SELECT * FROM Categories";

		// Crear el conjunto de datos y agregarle la tabla Categories:
		DataSet myDataSet = new DataSet();
		OleDbConnection myAccessConn = null;
		try
		{
			myAccessConn = new OleDbConnection(strAccessConn);
		}
		catch(Exception ex)
		{
			Console.WriteLine("Error: Failed to create a database connection. \n{0}", ex.Message);
			return;
		}

		try
		{
		
			OleDbCommand myAccessCommand = new OleDbCommand(strAccessSelect,myAccessConn);
			OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(myAccessCommand);

			myAccessConn.Open();
			myDataAdapter.Fill(myDataSet,"Categories");

		}
		catch (Exception ex)
		{
			Console.WriteLine("Error: Failed to retrieve the required data from the DataBase.\n{0}", ex.Message);
			return;
		}
		finally
		{
			myAccessConn.Close();
		}

		// Un conjunto de datos puede contener varias tablas, así que vamos a obtenerlas todas
		// en una matriz:
		DataTableCollection dta = myDataSet.Tables;
		foreach (DataTable dt in dta)
		{
			Console.WriteLine("Found data table {0}", dt.TableName);
		}
	    
		// Las dos líneas siguientes muestran dos formas diferentes de obtener el
		// recuento de tablas de un conjunto de datos:
		Console.WriteLine("{0} tables in data set", myDataSet.Tables.Count);
		Console.WriteLine("{0} tables in data set", dta.Count);
		// Las siguientes líneas muestran cómo obtener información sobre una
		// tabla específica por nombre desde el conjunto de datos:
		Console.WriteLine("{0} rows in Categories table", myDataSet.Tables["Categories"].Rows.Count);
		// La columna info se recupera automáticamente de la base de datos, por tanto,
		// podemos leerla aquí:
		Console.WriteLine("{0} columns in Categories table", myDataSet.Tables["Categories"].Columns.Count);
		DataColumnCollection drc = myDataSet.Tables["Categories"].Columns;
		int i = 0;
		foreach (DataColumn dc in drc)
		{
			// Imprimir el subíndice de la columna y después el nombre y su 
			// tipo de datos:
			Console.WriteLine("Column name[{0}] is {1}, of type {2}",i++ , dc.ColumnName, dc.DataType);
		}
		DataRowCollection dra = myDataSet.Tables["Categories"].Rows;
		foreach (DataRow dr in dra)
		{
			// Imprimir CategoryID como un subíndice y después CategoryName:
			Console.WriteLine("CategoryName[{0}] is {1}", dr[0], dr[1]);
		}
      
	}
}

