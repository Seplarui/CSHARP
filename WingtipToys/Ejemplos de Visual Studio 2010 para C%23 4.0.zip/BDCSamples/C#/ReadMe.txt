﻿' Copyright © Microsoft Corporation.  Reservados todos los derechos.
' Este código se publica según los términos 
' de licencia pública de Microsoft (MS-PL, 
' http://go.microsoft.com/?linkid=9791213).

*************Archivo Léame****************

Aplicable a proyectos de ejemplo de VB y C#.

En estos ejemplos de BDC, se conecta con la base de datos Northwind como origen 
de datos externo. Lea con atención las notas siguientes y asegúrese de que 
tiene conexión con la base de datos Northwind antes de ejecutar el proyecto de 
ejemplo.


*****************************************
Preparación de la base de datos Northwind
*****************************************

Si ya dispone de una base de datos Northwind, simplemente abra el archivo 
Setting.setting en cada proyecto y actualice NORTHWNDConnectionString con su 
propia cadena de conexión.

De lo contrario, siga estos pasos:

1. En los pasos siguientes se asume que ya tiene instalado en su equipo 
   SQL Express incluido gratuitamente con Visual Studio y SharePoint Server. Si 
   aún no lo tiene instalado, visite 
   http://www.microsoft.com/express/sql/download/ e instale SQL Express en 
   primer lugar.

2. Cree una base de datos "SampleNorthwind". Para ello, abra VS y vaya a 
   Ver->Explorador de servidores. Haga clic con el botón secundario del mouse 
   en el nodo Conexiones en la ventana Explorador de servidores y seleccione 
   Crear nueva base de datos de SQL Server.

3. En el cuadro de entrada de datos, escriba "localhost\sqlexpress" como Nombre 
   de servidor, y asigne el nombre "SampleNorthwind" a la nueva base de datos.

   * Si usa la versión de SQL Express que se incluye con SharePoint Server, 
     reemplace "localhost\sqlexpress" con "localhost\sharepoint".

4. Abra un símbolo del sistema.

5. En el símbolo del sistema, escriba lo siguiente y presione Entrar: 

	sqlcmd -S localhost\sqlexpress -d samplenorthwind -i <Ruta del archivo 
           CreateSampleNorthwindDB.sql>
   
   * CreateSampleNorthwindDB.sql está ubicado en la misma carpeta que el 
     archivo Léame. Creará automáticamente los datos y el esquema de tabla 
     Customer.


*****************************
Implementación del modelo BDC
*****************************

Ahora puede abrir los proyectos de ejemplo. Tendrá que especificar la URL del 
sitio del proyecto primero. Para hacerlo, haga clic en el nodo del proyecto y 
en la ventana Propiedades establezca el sitio URL en "http://localhost". Ahora 
presione F5 para depurar o Compilar>Implementar para implementar el modelo BDC.

* Tenga en cuenta que si desea usar ambos proyectos de ejemplo, es recomendable 
  crear una segunda tabla de base de datos para conectarla al segundo proyecto.

Actualmente, ambos proyectos de ejemplo están conectados a la misma base de 
datos recién creada por lo que es posible que, en tiempo de ejecución, solo un 
proyecto se conecte correctamente a la base de datos. Para evitar conflictos de 
datos, es muy recomendable crear una segunda tabla. Para ello, siga los pasos 
anteriores usando un nombre de tabla diferente. Una vez hecho, simplemente abra 
el archivo Setting.setting del proyecto y cambie NORTHWNDConnectionString para 
conectar con la nueva tabla.


*******************************************************
Creación de una lista externa en un sitio de SharePoint
*******************************************************

Una vez implementado correctamente el modelo BDC, puede crear una lista externa 
en el sitio de SharePoint para manipular los datos. 

Para ello: 

1. Vaya a la página principal de su sitio de SharePoint. Normalmente es 
   Http://localhost.
2. En la esquina superior izquierda del sitio, seleccione Acciones del sitio -> 
   Más opciones. 
3. En la página Crear, haga clic en Lista externa.
4. En la página Nueva, asigne un nombre a la lista. En la sección Configuración 
   de origen de datos, haga clic en el botón Seleccionar tipo de contenido 
   externo. En el cuadro del Selector de tipo de contenido externo, seleccione 
   el tipo recién implementado, BdcSampleCSharp.BdcModel1.Customer o 
   BdcSampleVB.Customer.

   *Nota: Si no puede ver ningún tipo en el seleccionador de tipo de contenido 
    externo, probablemente sea debido a que no tiene concedido el permiso de 
    acceso al repositorio de bases de datos de BDC. Para conceder el permiso, 
    vaya a la página Administración central de SharePoint, haga clic en las 
    aplicaciones Administrar servicio, después haga clic en Servicio de 
    conectividad a datos profesionales. En la página Ver tipos de contenido 
    externo, haga clic en Establecer permisos del Repositorio de metadatos en 
    la cinta. Después, agregue su nombre de usuario en Establecer permisos del 
    Repositorio de metadatos y conceda el permiso.

5. Haga clic en la página Nueva.

Ahora debería poder ver una lista de clientes en la página de SharePoint y 
crear, actualizar o eliminar la información de los clientes. Los cambios se 
realizarán en la base de datos en tiempo real.
