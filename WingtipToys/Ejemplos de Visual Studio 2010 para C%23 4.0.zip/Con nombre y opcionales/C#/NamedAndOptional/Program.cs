﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NamedAndOptional
{
    // Este programa muestra cómo declarar un método con los parámetros named
    // y optional, y cómo llamar al método mediante
    // el uso explícito de estos parámetros.
    class Program
    {
        // Método con los parámetros named y optional
        public static void Search(string name, int age = 21, string city = "Pueblo")
        {
            Console.WriteLine("Name = {0} - Age = {1} - City = {2}", name, age, city);
        }

        static void Main(string[] args)
        {
            // Llamada estándar
            Search("Sue", 22, "New York");

            // Omitir parámetro city
            Search("Mark", 23);

            // Asignar un nombre explícitamente al parámetro city
            Search("Lucy", city: "Cairo");

            // Usar parámetros named en el orden inverso
            Search("Pedro", age: 45, city: "Saigon");
        }
    }
}
