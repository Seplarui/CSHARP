﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

using System;
using System.Collections.Generic;
using System.Text;

namespace Yield
{
    class Yield
    {
        public static class NumberList
        {
            // Crear una matriz de enteros.
            public static int[] ints = { 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377 };

            // Definir una propiedad que devuelva sólo números pares.
            public static IEnumerable<int> GetEven()
            {
                // Utilizar yield para devolver números pares en la lista.
                foreach (int i in ints)
                    if (i % 2 == 0)
                        yield return i;
            }

            // Definir una propiedad que devuelva sólo números pares.
            public static IEnumerable<int> GetOdd()
            {
                // Utilizar yield para devolver sólo números impares.
                foreach (int i in ints)
                    if (i % 2 == 1)
                        yield return i;
            }
        }

        static void Main(string[] args)
        {

            // Mostrar números pares.
            Console.WriteLine("Even numbers");
            foreach (int i in NumberList.GetEven())
                Console.WriteLine(i);

            // Mostrar números impares.
            Console.WriteLine("Odd numbers");
            foreach (int i in NumberList.GetOdd())
                Console.WriteLine(i);
        }
    }
}

