﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

using System;

class NullableBoxing
{
    static void Main()
    {
        int? a;
        object oa;

        // Asigna a a Nullable<int> (value = default(int), hasValue = false).
        a = null;

        // Asigna oa a null (because x==null), ¿"int" sin conversión boxing?"
        oa = a;

        Console.WriteLine("Testing 'a' and 'boxed a' for null...");
        // Las variables que admiten Null se pueden comparar con Null.
        if (a == null)
        {
            Console.WriteLine("  a == null");
        }

        // Las variables que admiten Null con conversión boxing se pueden comparar con Null
        // porque aplicar conversión boxing a una variable que admite Null donde HasValue==false
        // establece la referencia en Null.
        if (oa == null)
        {
            Console.WriteLine("  oa == null");
        }

        Console.WriteLine("Unboxing a nullable type...");
        int? b = 10;
        object ob = b;

        // A los tipos que aceptan valores NULL con conversión boxing se les puede aplicar conversión unboxing
        int? unBoxedB = (int?)ob;
        Console.WriteLine("  b={0}, unBoxedB={0}", b, unBoxedB);

        // Aplicar conversión unboxing a un tipo que acepte valores NULL establecido en NULL funciona si
        // se le aplica la conversión unboxing en un tipo que acepta valores NULL.
        int? unBoxedA = (int?)oa;
        if (oa == null && unBoxedA == null)
        {
            Console.WriteLine("  a and unBoxedA are null");
        }

        Console.WriteLine("Attempting to unbox into non-nullable type...");
        // Aplicar conversión unboxing a un tipo que acepte valores NULL establecido en NULL produce una
        // excepción si se le aplica la conversión unboxing en un tipo que no acepta valores NULL.
        try
        {
            int unBoxedA2 = (int)oa;
        }
        catch (Exception e)
        {
            Console.WriteLine("  {0}", e.Message);
        }
    }

}
