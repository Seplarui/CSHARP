﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

using System;

class NullableOperator
{
    static int? GetNullableInt()
    {
        return null;
    }

    static string GetStringValue()
    {
        return null;
    }

    static void Main()
    {
        // Ejemplo del operador ??.
        int? x = null;

        // y = x, a menos que x sea null, en cuyo caso y = -1.
        int y = x ?? -1;
        Console.WriteLine("y == " + y);                          

        // Asignar i al valor devuelto del método, a menos
        // que el valor devuelto sea Null, en cuyo caso, se asigna
        // el valor predeterminado de int a i.
        int i = GetNullableInt() ?? default(int);
        Console.WriteLine("i == " + i);                          

        // ?? funciona también con tipos de referencia. 
        string s = GetStringValue();
        // Mostrar contenido de s, a menos que s sea Null, 
        // en cuyo caso mostrar "Unspecified".
        Console.WriteLine("s = {0}", s ?? "null");
    }
}
