﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// AttributesTutorial.cs
// Este ejemplo muestra el uso de atributos de clase y método.

using System;
using System.Reflection;
using System.Collections;

// La clase IsTested es una clase de atributos personalizada definida por el usuario.
// Se puede aplicar a cualquier declaración que incluya
//  - tipos (struct, class, enum, delegate)
//  - miembros (métodos, campos, eventos, propiedades, indizadores)
// Se utiliza sin argumentos.
public class IsTestedAttribute : Attribute
{
    public override string ToString()
    {
        return "Is Tested";
    }
}

// La clase AuthorAttribute es una clase de atributos definida por el usuario.
// Se puede aplicar sólo a clases y declaraciones struct.
// Toma un argumento de cadena sin nombre (nombre del autor).
// Tiene un argumento sin nombre opcional Version, que es de tipo int.
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
public class AuthorAttribute : Attribute
{
    // Este constructor especifica los argumentos sin nombre como para la clase de atributos.
    public AuthorAttribute(string name)
    {
        this.name = name;
        this.version = 0;
    }

    // Esta propiedad es de sólo lectura (no tiene un descriptor de acceso set),
    // por tanto, no se puede utilizar como un argumento con nombre para este atributo.
    public string Name 
    {
        get 
        {
            return name;
        }
    }

    // Esta propiedad es de lectura y escritura (tiene un descriptor de acceso set).
    // por tanto, se puede utilizar como un argumento con nombre cuando se utilice esta
    // clase como una clase de atributos.
    public int Version
    {
        get 
        {
            return version;
        }
        set 
        {
            version = value;
        }
    }

    public override string ToString()
    {
        string value = "Author : " + Name;
        if (version != 0)
        {
            value += " Version : " + Version.ToString();
        }
        return value;
    }

    private string name;
    private int version;
}

// Aquí se adjunta el atributo personalizado AuthorAttribute definido por el usuario a
// la clase Account. El argumento de cadena sin nombre se pasa al
// constructor de la clase AuthorAttribute cuando se crean los atributos.
[Author("Joe Programmer")]
class Account
{
    // Adjuntar el atributo personalizado IsTestedAttribute a este método.
    [IsTested]
    public void AddOrder(Order orderToAdd)
    {
        orders.Add(orderToAdd);
    }

    private ArrayList orders = new ArrayList();
}

// Adjuntar los atributos personalizados AuthorAttribute y IsTestedAttribute
// a esta clase.
// Observe el uso del argumento con nombre 'Version' para AuthorAttribute.
[Author("Jane Programmer", Version = 2), IsTested()]
class Order
{
    // y más cosas aquí...
}

class MainClass
{
   private static bool IsMemberTested(MemberInfo member)
   {
        foreach (object attribute in member.GetCustomAttributes(true))
        {
            if (attribute is IsTestedAttribute)
            {
               return true;
            }
        }
      return false;
   }

    private static void DumpAttributes(MemberInfo member)
    {
        Console.WriteLine("Attributes for : " + member.Name);
        foreach (object attribute in member.GetCustomAttributes(true))
        {
            Console.WriteLine(attribute);
        }
    }

    public static void Main()
    {
        // Mostrar atributos para la clase Account
        DumpAttributes(typeof(Account));

        // Mostrar la lista de miembros probados
        foreach (MethodInfo method in (typeof(Account)).GetMethods())
        {
            if (IsMemberTested(method))
            {
               Console.WriteLine("Member {0} is tested!", method.Name);
            }
            else
            {
               Console.WriteLine("Member {0} is NOT tested!", method.Name);
            }
        }
        Console.WriteLine();

        // Mostrar atributos para la clase Order
        DumpAttributes(typeof(Order));

        // Mostrar atributos para los métodos de la clase Order
        foreach (MethodInfo method in (typeof(Order)).GetMethods())
        {
           if (IsMemberTested(method))
           {
               Console.WriteLine("Member {0} is tested!", method.Name);
           }
           else
           {
               Console.WriteLine("Member {0} is NOT tested!", method.Name);
           }
        }
        Console.WriteLine();
    }
}


