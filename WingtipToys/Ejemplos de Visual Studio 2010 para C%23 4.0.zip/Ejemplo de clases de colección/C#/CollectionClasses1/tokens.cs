﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// tokens.cs
using System;
// Se pone disponible el espacio de nombres System.Collections:
using System.Collections;

// Declarar la clase Tokens:
public class Tokens : IEnumerable
{
   private string[] elements;

   Tokens(string source, char[] delimiters)
   {
      // Analizar la cadena en símbolos (tokens):
      elements = source.Split(delimiters);
   }

   // Implementación de la interfaz Enumerable:
   //   Declaración del método GetEnumerator()
   //   requerido por IEnumerable
   public IEnumerator GetEnumerator()
   {
      return new TokenEnumerator(this);
   }

   // La clase interna implementa la interfaz IEnumerator:
   private class TokenEnumerator : IEnumerator
   {
      private int position = -1;
      private Tokens t;

      public TokenEnumerator(Tokens t)
      {
         this.t = t;
      }

      // Declarar el método MoveNext requerido por IEnumerator:
      public bool MoveNext()
      {
         if (position < t.elements.Length - 1)
         {
            position++;
            return true;
         }
         else
         {
            return false;
         }
      }

      // Declarar el método Reset requerido por IEnumerator:
      public void Reset()
      {
         position = -1;
      }

      // Declarar la propiedad Current requerida por IEnumerator:
      public object Current
      {
         get
         {
            return t.elements[position];
         }
      }
   }

   // Probar Tokens, TokenEnumerator

   static void Main()
   {
      // Probar Tokens dividiendo la cadena en símbolos (tokens):
      Tokens f = new Tokens("This is a well-done program.", 
         new char[] {' ','-'});
      foreach (string item in f)
      {
         Console.WriteLine(item);
      }
   }
}

