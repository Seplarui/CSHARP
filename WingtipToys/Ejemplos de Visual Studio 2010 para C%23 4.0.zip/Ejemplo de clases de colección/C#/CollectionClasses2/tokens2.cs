﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// tokens2.cs
using System;
using System.Collections;

public class Tokens: IEnumerable
{
   private string[] elements;

   Tokens(string source, char[] delimiters)
   {
      elements = source.Split(delimiters);
   }

   // Implementación de la interfaz Enumerable:

   public TokenEnumerator GetEnumerator() // Versión no IEnumerable
   {
      return new TokenEnumerator(this);
   }

   IEnumerator IEnumerable.GetEnumerator() // Versión IEnumerable
   {
      return (IEnumerator) new TokenEnumerator(this);
   }

   // La clase interna implementa la interfaz IEnumerator:

   public class TokenEnumerator: IEnumerator
   {
      private int position = -1;
      private Tokens t;

      public TokenEnumerator(Tokens t)
      {
         this.t = t;
      }

      public bool MoveNext()
      {
         if (position < t.elements.Length - 1)
         {
            position++;
            return true;
         }
         else
         {
            return false;
         }
      }

      public void Reset()
      {
         position = -1;
      }

      public string Current // Versión no IEnumerator: seguridad de tipos
      {
         get
         {
            return t.elements[position];
         }
      }

      object IEnumerator.Current // Versión IEnumerator: devuelve un objeto
      {
         get
         {
            return t.elements[position];
         }
      }
   }

   // Probar Tokens, TokenEnumerator

   static void Main()
   {
      Tokens f = new Tokens("This is a well-done program.", 
         new char [] {' ','-'});
      foreach (string item in f) // Probar cambiando la cadena a int
      {
         Console.WriteLine(item);
      }
   }
}

