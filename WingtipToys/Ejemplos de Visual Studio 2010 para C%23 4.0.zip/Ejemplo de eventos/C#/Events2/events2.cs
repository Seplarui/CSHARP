﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// events2.cs
using System;
namespace MyCollections 
{
   using System.Collections;

   // Clase que funciona como ArrayList, pero envía notificaciones de evento
   // cuando cambia la lista:
   public class ListWithChangedEvent: ArrayList 
   {
      // Evento que pueden utilizar los clientes para que se les notifique siempre que
      // cambien los elementos de la lista:
      public event EventHandler Changed;

      // Invocar al evento Changed; se le llama siempre que cambia la lista:
      protected virtual void OnChanged(EventArgs e) 
      {
         if (Changed != null)
            Changed(this,e);
      }

      // Invalidar algunos de los métodos que pueden cambiar la lista;
      // invocar al evento después de cada uno:
      public override int Add(object value) 
      {
         int i = base.Add(value);
         OnChanged(EventArgs.Empty);
         return i;
      }

      public override void Clear() 
      {
         base.Clear();
         OnChanged(EventArgs.Empty);
      }

      public override object this[int index] 
      {
         set 
         {
            base[index] = value;
            OnChanged(EventArgs.Empty);
         }
      }
   }
}

namespace TestEvents 
{
   using MyCollections;

   class EventListener 
   {
      private ListWithChangedEvent List;

      public EventListener(ListWithChangedEvent list) 
      {
         List = list;
         // Agregar "ListChanged" al evento Changed en "List":
         List.Changed += new EventHandler(ListChanged);
      }

      // Se llamará siempre que cambie la lista:
      private void ListChanged(object sender, EventArgs e) 
      {
         Console.WriteLine("This is called when the event fires.");
      }

      public void Detach() 
      {
         // Desasociar el evento y eliminar la lista:
         List.Changed -= new EventHandler(ListChanged);
         List = null;
      }
   }

   class Test 
   {
      // Probar la clase ListWithChangedEvent:
      public static void Main() 
      {
      // Crear una lista nueva:
      ListWithChangedEvent list = new ListWithChangedEvent();

      // Crear una clase que escuche al evento de cambio de la lista:
      EventListener listener = new EventListener(list);

      // Agregar y quitar elementos de la lista:
      list.Add("item 1");
      list.Clear();
      listener.Detach();
      }
   }
}

