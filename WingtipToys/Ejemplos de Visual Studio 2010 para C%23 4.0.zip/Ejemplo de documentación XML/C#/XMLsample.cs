﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// XMLsample.cs
// compilar con: /doc:XMLsample.xml
using System;

/// <summary>
/// Aquí viene documentación resumida de nivel de clase.</summary>
/// <remarks>
/// Los comentarios más largos se pueden asociar con un tipo o miembro
/// con la etiqueta remarks</remarks>
public class SomeClass
{
   /// <summary>
   /// Almacén de la propiedad name</summary>
   private string myName = null;

   /// <summary>
   ///Constructor de la clase. </summary>
   public SomeClass()
   {
       // TODO: Agregar aquí la lógica del constructor
   }
   
   /// <summary>
   /// Propiedad Name </summary>
   /// <value>
   /// Se utiliza una etiqueta value para describir el valor de la propiedad</value>
   public string Name
   {
      get 
      {
         if ( myName == null )
         {
            throw new Exception("Name is null");
         }
             
         return myName;
      }
   }

   /// <summary>
   /// Descripción de SomeMethod.</summary>
   /// <param name="s"> Descripción de parámetro para s</param>
   /// <seealso cref="String">
   /// Puede utilizar el atributo cref con cualquier etiqueta para hacer referencia a un tipo o un miembro
   /// y el compilador comprobará que la referencia existe. </seealso>
   public void SomeMethod(string s)
   {
   }

   /// <summary>
   /// Algún otro método. </summary>
   /// <returns>
   /// Los resultados devueltos se describen con la etiqueta returns.</returns>
   /// <seealso cref="SomeMethod(string)">
   /// Observe el uso del atributo cref para hacer referencia a un método específico</seealso>
   public int SomeOtherMethod()
   {
      return 0;
   }

   /// <summary>
   /// Punto de entrada de la aplicación.
   /// </summary>
   /// <param name="args"> Lista de argumentos de la línea de comandos</param>
   public static int Main(String[] args)
   {
      // TODO: Agregar aquí el código para iniciar la aplicación

       return 0;
   }
}

