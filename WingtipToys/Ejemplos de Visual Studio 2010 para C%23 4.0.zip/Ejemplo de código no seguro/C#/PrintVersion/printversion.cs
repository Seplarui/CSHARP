﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// printversion.cs
// compilar con: /unsafe
using System;
using System.Reflection;
using System.Runtime.InteropServices;

// Dar a este ensamblado un número de versión:
[assembly:AssemblyVersion("4.3.2.1")]

public class Win32Imports 
{
	[DllImport("version.dll")]
	public static extern bool GetFileVersionInfo (string sFileName,
		int handle, int size, byte[] infoBuffer);
	[DllImport("version.dll")]
	public static extern int GetFileVersionInfoSize (string sFileName,
		out int handle);
   
	// Las referencias del tercer parámetro ("out string pValue") se calculan
	// automáticamente de Ansi a Unicode:
	[DllImport("version.dll")]
	unsafe public static extern bool VerQueryValue (byte[] pBlock,
		string pSubBlock, out string pValue, out uint len);
	// Esta sobrecarga VerQueryValue se marca con 'unsafe' porque
	// utiliza un valor short*:
	[DllImport("version.dll")]
	unsafe public static extern bool VerQueryValue (byte[] pBlock,
		string pSubBlock, out short *pValue, out uint len);
}

public class C 
{
	// Main se marca con 'unsafe' porque utiliza punteros:
	unsafe public static int Main () 
	{
		try 
		{
			int handle = 0;
			// Averiguar qué información de versión hay:
			int size =
				Win32Imports.GetFileVersionInfoSize("printversion.exe",
				out handle);

			if (size == 0) return -1;

			byte[] buffer = new byte[size];

			if (!Win32Imports.GetFileVersionInfo("printversion.exe", handle, size, buffer))
			{
				Console.WriteLine("Failed to query file version information.");
				return 1;
			}

			short *subBlock = null;
			uint len = 0;
			// Obtener información de configuración regional de la información de versión:
			if (!Win32Imports.VerQueryValue (buffer, @"\VarFileInfo\Translation", out subBlock, out len))
			{
				Console.WriteLine("Failed to query version information.");
				return 1;
			}

			string spv = @"\StringFileInfo\" + subBlock[0].ToString("X4") + subBlock[1].ToString("X4") + @"\ProductVersion";

			byte *pVersion = null;
			// Obtener el valor ProductVersion para este programa:
			string versionInfo;
			
			if (!Win32Imports.VerQueryValue (buffer, spv, out versionInfo, out len))
			{
				Console.WriteLine("Failed to query version information.");
				return 1;
			}

			Console.WriteLine ("ProductVersion == {0}", versionInfo);
		}
		catch (Exception e) 
		{
			Console.WriteLine ("Caught unexpected exception " + e.Message);
		}
      
		return 0;
	}
}

