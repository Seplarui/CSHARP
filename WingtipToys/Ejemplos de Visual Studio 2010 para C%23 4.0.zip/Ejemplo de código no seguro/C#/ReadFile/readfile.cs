﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// readfile.cs
// compilar con: /unsafe
// argumentos: readfile.txt

// Utilizar este programa para leer y mostrar un archivo de texto.
using System;
using System.Runtime.InteropServices;
using System.Text;

class FileReader
{
	const uint GENERIC_READ = 0x80000000;
	const uint OPEN_EXISTING = 3;
	IntPtr handle;

	[DllImport("kernel32", SetLastError=true)]
	static extern unsafe IntPtr CreateFile(
		string FileName,				// Nombre de archivo
		uint DesiredAccess,				// Modo de acceso
		uint ShareMode,					// Modo de uso compartido
		uint SecurityAttributes,		// Atributos de seguridad
		uint CreationDisposition,		// Cómo crear
		uint FlagsAndAttributes,		// atributos de archivo
		int hTemplateFile				// Identificador del archivo de plantilla
		);



	[DllImport("kernel32", SetLastError=true)]
	static extern unsafe bool ReadFile(
		IntPtr hFile,					// Identificador de archivo
		void* pBuffer,				// Búfer de datos
		int NumberOfBytesToRead,	// Número de bytes para leer
		int* pNumberOfBytesRead,		// Número de bytes leídos
		int Overlapped				// Búfer superpuesto
		);


	[DllImport("kernel32", SetLastError=true)]
	static extern unsafe bool CloseHandle(
		IntPtr hObject   // Identificador de objeto
		);
	
	public bool Open(string FileName)
	{
		// Abrir el archivo existente para leerlo
		
		handle = CreateFile(
			FileName,
			GENERIC_READ,
			0, 
			0, 
			OPEN_EXISTING,
			0,
			0);
	
		if (handle != IntPtr.Zero)
			return true;
		else
			return false;
	}

	public unsafe int Read(byte[] buffer, int index, int count) 
	{
		int n = 0;
		fixed (byte* p = buffer) 
		{
			if (!ReadFile(handle, p + index, count, &n, 0))
				return 0;
		}
		return n;
	}

	public bool Close()
	{
		//Cerrar el identificador de archivo
		return CloseHandle(handle);
	}
}

class Test
{
	public static int Main(string[] args)
	{
		if (args.Length != 1)
		{
			Console.WriteLine("Usage : ReadFile <FileName>");
			return 1;
		}
		
		if (! System.IO.File.Exists(args[0]))
		{
			Console.WriteLine("File " + args[0] + " not found."); 
			return 1;
		}

		byte[] buffer = new byte[128];
		FileReader fr = new FileReader();
		
		if (fr.Open(args[0]))
		{
			
			// Asumimos que estamos leyendo un archivo ASCII
			ASCIIEncoding Encoding = new ASCIIEncoding();
			
			int bytesRead;
			do 
			{
				bytesRead = fr.Read(buffer, 0, buffer.Length);
				string content = Encoding.GetString(buffer,0,bytesRead);
				Console.Write("{0}", content);
			}
			while ( bytesRead > 0);
			
			fr.Close();
			return 0;
		}
		else
		{
			Console.WriteLine("Failed to open requested file");
			return 1;
		}
	}
}
