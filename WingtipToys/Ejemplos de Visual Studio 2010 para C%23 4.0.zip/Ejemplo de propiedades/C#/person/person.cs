﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// person.cs
using System;
class Person
{
    private string myName ="N/A";
    private int myAge = 0;

    // Declarar una propiedad Name de tipo String:
    public string Name
    {
        get 
        {
           return myName; 
        }
        set 
        {
           myName = value; 
        }
    }

    // Declarar una propiedad Age de tipo int:
    public int Age
    {
        get 
        { 
           return myAge; 
        }
        set 
        { 
           myAge = value; 
        }
    }

    public override string ToString()
    {
        return "Name = " + Name + ", Age = " + Age;
    }

    public static void Main()
    {
        Console.WriteLine("Simple Properties");

        // Crear un nuevo objeto Person:
        Person person = new Person();

        // Imprimir el nombre y la edad asociados con la persona:
        Console.WriteLine("Person details - {0}", person);

        // Establecer algunos valores en el objeto Person:
        person.Name = "Joe";
        person.Age = 99;
        Console.WriteLine("Person details - {0}", person);

        // Incrementar la propiedad Age:
        person.Age += 1;
        Console.WriteLine("Person details - {0}", person);
    }
}

