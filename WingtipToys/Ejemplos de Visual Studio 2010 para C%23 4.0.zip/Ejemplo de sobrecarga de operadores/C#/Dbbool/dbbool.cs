﻿// Copyright © Microsoft Corporation. Reservados todos los derechos.
// Este código se ha publicado de acuerdo con los términos de la 
// licencia pública de Microsoft (MS-PL, http://opensource.org/licenses/ms-pl.html).
//
//(C) Microsoft Corporation. Reservados todos los derechos.

// dbbool.cs
using System;

public struct DBBool
{
   // Los tres valores DBBool posibles:
   public static readonly DBBool dbNull = new DBBool(0);
   public static readonly DBBool dbFalse = new DBBool(-1);
   public static readonly DBBool dbTrue = new DBBool(1);
   // Campo privado que almacena -1, 0, 1 para dbFalse, dbNull, dbTrue:
   int value; 

   // Constructor privado. El parámetro de valor debe ser -1, 0 o 1:
   DBBool(int value) 
   {
      this.value = value;
   }

   // Conversión implícita de bool a DBBool. Asigna True a 
   // DBBool.dbTrue y False a DBBool.dbFalse:
   public static implicit operator DBBool(bool x) 
   {
      return x? dbTrue: dbFalse;
   }

   // Conversión explícita de DBBool a bool. Produce una
   // excepción si el DBBool dado es dbNull; de lo contrario, devuelve
   // True o False:
   public static explicit operator bool(DBBool x) 
   {
      if (x.value == 0) throw new InvalidOperationException();
      return x.value > 0;
   }

   // Operador de igualdad. Devuelve dbNull si alguno de los operandos es dbNull, 
   // de lo contrario, devuelve dbTrue o dbFalse:
   public static DBBool operator ==(DBBool x, DBBool y) 
   {
      if (x.value == 0 || y.value == 0) return dbNull;
      return x.value == y.value? dbTrue: dbFalse;
   }

   // Operador de desigualdad. Devuelve dbNull si alguno de los operandos es
   // dbNull; de lo contrario, devuelve dbTrue o dbFalse:
   public static DBBool operator !=(DBBool x, DBBool y) 
   {
      if (x.value == 0 || y.value == 0) return dbNull;
      return x.value != y.value? dbTrue: dbFalse;
   }

   // Operador de negación lógica. Devuelve dbTrue si el operando es
   // dbFalse, dbNull si el operando es dbNull o dbFalse si el
   // operando es dbTrue:
   public static DBBool operator !(DBBool x) 
   {
      return new DBBool(-x.value);
   }

   // Operador AND lógico. Devuelve dbFalse si algún operando es 
   // dbFalse, dbNull si algún operando es dbNull; de lo contrario, dbTrue:
   public static DBBool operator &(DBBool x, DBBool y) 
   {
      return new DBBool(x.value < y.value? x.value: y.value);
   }

   // Operador OR lógico. Devuelve dbTrue si algún operando es
   // dbTrue, dbNull si algún operando es dbNull; de lo contrario, dbFalse:
   public static DBBool operator |(DBBool x, DBBool y) 
   {
      return new DBBool(x.value > y.value? x.value: y.value);
   }

   // Operador definitivamente True. Devuelve true si el operando es
   // dbTrue; de lo contrario, False:
   public static bool operator true(DBBool x) 
   {
      return x.value > 0;
   }

   // Operador definitivamente False. Devuelve true si el operando es 
   // dbFalse; de lo contrario, False:
   public static bool operator false(DBBool x) 
   {
      return x.value < 0;
   }

   // Sobrecargar la conversión de DBBool a String:
   public static implicit operator string(DBBool x) 
   {
      return x.value > 0 ? "dbTrue"
           : x.value < 0 ? "dbFalse"
           : "dbNull";
   }

   // Invalidar el método Object.Equals(object o):
   public override bool Equals(object o) 
   {
      try 
      {
         return (bool) (this == (DBBool) o);
      }
      catch 
      {
         return false;
      }
   }

   // Invalidar el método Object.GetHashCode():
   public override int GetHashCode() 
   {
      return value;
   }

   // Invalidar el método ToString para convertir DBBool en String:
   public override string ToString() 
   {
      switch (value) 
      {
         case -1:
            return "DBBool.False";
         case 0:
            return "DBBool.Null";
         case 1:
            return "DBBool.True";
         default:
            throw new InvalidOperationException();
      }
   }
}

class Test 
{
   static void Main() 
   {
      DBBool a, b;
      a = DBBool.dbTrue;
      b = DBBool.dbNull;

      Console.WriteLine( "!{0} = {1}", a, !a);
      Console.WriteLine( "!{0} = {1}", b, !b);
      Console.WriteLine( "{0} & {1} = {2}", a, b, a & b);
      Console.WriteLine( "{0} | {1} = {2}", a, b, a | b);
      // Invocar el operador True para determinar el valor Boolean 
      // de la variable DBBool:
      if (b)
         Console.WriteLine("b is definitely true");
      else
         Console.WriteLine("b is not definitely true");   
   }
}

